module.exports = {
  // eslint-disable-next-line global-require
  plugins: [require('autoprefixer')]
};
